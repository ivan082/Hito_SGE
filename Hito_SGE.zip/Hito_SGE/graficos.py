from matplotlib import pyplot as plt

# Mostrar gráfico del consumo por edad
def mostrar_grafico():
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT edad, BebidasSemana FROM ENCUESTA")
        rows = cursor.fetchall()
        edades = [row[0] for row in rows]
        bebidas = [row[1] for row in rows]

        plt.bar(edades, bebidas, color='blue')
        plt.xlabel("Edades")
        plt.ylabel("Bebidas por Semana")
        plt.title("Consumo de Bebidas por Edad")
        plt.show()
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo generar el gráfico: {e}")
    finally:
        conn.close()
