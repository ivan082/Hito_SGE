import sqlite3

# Función de conexión
def conectar():
    return sqlite3.connect('encuestas.db')  
# Crear la tabla ENCUESTA
def crear_tabla():
    try:
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS ENCUESTA (
            idEncuesta INTEGER PRIMARY KEY,
            edad INTEGER,
            Sexo TEXT,
            BebidasSemana INTEGER,
            CervezasSemana INTEGER
        )
        """)
        conn.commit()
        print("Tabla 'ENCUESTA' creada correctamente.")
    except Exception as e:
        print(f"Error al crear la tabla: {e}")
    finally:
        conn.close()

# Ejecutar la función para crear la tabla
if __name__ == "__main__":
    crear_tabla()
