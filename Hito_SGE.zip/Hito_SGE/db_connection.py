import mysql.connector

# Configuración de la conexión a la base de datos
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "encuesas"
}

# Conexión a la base de datos
def conectar():
    return mysql.connector.connect(**db_config)
