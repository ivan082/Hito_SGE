from tkinter import messagebox
import tkinter as tk
from tkinter import ttk
import sqlite3  

# Función para conectar con la base de datos
def conectar():
    return sqlite3.connect('encuestas.db') 
# Función para crear una encuesta
def crear_encuesta():
    try:
        conn = conectar()
        cursor = conn.cursor()
        query = """
        INSERT INTO ENCUESTA (idEncuesta, edad, Sexo, BebidasSemana, CervezasSemana)
        VALUES (?, ?, ?, ?, ?)
        """
        data = (
            id_entry.get(), edad_entry.get(), sexo_combo.get(),
            bebidas_semana_entry.get(), cervezas_semana_entry.get()
        )
        cursor.execute(query, data)
        conn.commit()
        messagebox.showinfo("Éxito", "Encuesta creada correctamente.")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo crear la encuesta: {e}")
    finally:
        conn.close()
        leer_encuestas()  

# Función para actualizar una encuesta
def actualizar_encuesta():
    try:
        conn = conectar()
        cursor = conn.cursor()
        query = """
        UPDATE ENCUESTA
        SET edad = ?, Sexo = ?, BebidasSemana = ?, CervezasSemana = ?
        WHERE idEncuesta = ?
        """
        data = (
            edad_entry.get(), sexo_combo.get(),
            bebidas_semana_entry.get(), cervezas_semana_entry.get(),
            id_entry.get()
        )
        cursor.execute(query, data)
        conn.commit()
        messagebox.showinfo("Éxito", "Encuesta actualizada correctamente.")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo actualizar la encuesta: {e}")
    finally:
        conn.close()
        leer_encuestas()

# Función para eliminar una encuesta
def eliminar_encuesta():
    try:
        conn = conectar()
        cursor = conn.cursor()
        query = "DELETE FROM ENCUESTA WHERE idEncuesta = ?"
        cursor.execute(query, (id_entry.get(),))
        conn.commit()
        messagebox.showinfo("Éxito", "Encuesta eliminada correctamente.")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo eliminar la encuesta: {e}")
    finally:
        conn.close()
        leer_encuestas()

# Función para leer las encuestas de la base de datos
def leer_encuestas():
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ENCUESTA")
        rows = cursor.fetchall()
        for row in rows:
            tree.insert("", "end", values=row)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudieron leer las encuestas: {e}")
    finally:
        conn.close()

# Función para mostrar el gráfico
def mostrar_grafico():
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT edad, BebidasSemana FROM ENCUESTA")
        rows = cursor.fetchall()
        edades = [row[0] for row in rows]
        bebidas = [row[1] for row in rows]

        plt.bar(edades, bebidas, color='blue')
        plt.xlabel("Edades")
        plt.ylabel("Bebidas por Semana")
        plt.title("Consumo de Bebidas por Edad")
        plt.show()
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo generar el gráfico: {e}")
    finally:
        conn.close()

# Configuración de la ventana principal
root = tk.Tk()
root.title("Gestión de Encuestas")

# Frame de Entradas
frame = tk.Frame(root)
frame.pack(pady=10)

# Campos de entrada
tk.Label(frame, text="ID").grid(row=0, column=0)
id_entry = tk.Entry(frame)
id_entry.grid(row=0, column=1)

tk.Label(frame, text="Edad").grid(row=1, column=0)
edad_entry = tk.Entry(frame)
edad_entry.grid(row=1, column=1)

tk.Label(frame, text="Sexo").grid(row=2, column=0)
sexo_combo = ttk.Combobox(frame, values=["Hombre", "Mujer"])
sexo_combo.grid(row=2, column=1)

tk.Label(frame, text="Bebidas/Semana").grid(row=3, column=0)
bebidas_semana_entry = tk.Entry(frame)
bebidas_semana_entry.grid(row=3, column=1)

tk.Label(frame, text="Cervezas/Semana").grid(row=4, column=0)
cervezas_semana_entry = tk.Entry(frame)
cervezas_semana_entry.grid(row=4, column=1)

# Botones
tk.Button(frame, text="Crear", command=crear_encuesta).grid(row=5, column=0, pady=10)
tk.Button(frame, text="Actualizar", command=actualizar_encuesta).grid(row=5, column=1, pady=10)
tk.Button(frame, text="Eliminar", command=eliminar_encuesta).grid(row=5, column=2, pady=10)
tk.Button(frame, text="Gráfico", command=mostrar_grafico).grid(row=5, column=3, pady=10)

# Tabla de Datos
columns = ("ID", "Edad", "Sexo", "Bebidas/Semana", "Cervezas/Semana")
tree = ttk.Treeview(root, columns=columns, show="headings")
for col in columns:
    tree.heading(col, text=col)
tree.pack(pady=10)

# Cargar datos iniciales
leer_encuestas()

# Iniciar el bucle de la interfaz
root.mainloop()
