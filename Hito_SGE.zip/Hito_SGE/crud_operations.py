from tkinter import messagebox

# Crear un nuevo registro
def crear_encuesta():
    try:
        conn = conectar()
        cursor = conn.cursor()
        query = """
        INSERT INTO ENCUESTA (idEncuesta, edad, Sexo, BebidasSemana, CervezasSemana)
        VALUES (%s, %s, %s, %s, %s)
        """
        data = (
            id_entry.get(), edad_entry.get(), sexo_combo.get(),
            bebidas_semana_entry.get(), cervezas_semana_entry.get()
        )
        cursor.execute(query, data)
        conn.commit()
        messagebox.showinfo("Éxito", "Encuesta creada correctamente.")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo crear la encuesta: {e}")
    finally:
        conn.close()
        leer_encuestas()

# Leer registros
def leer_encuestas():
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ENCUESTA")
        rows = cursor.fetchall()
        for row in tree.get_children():
            tree.delete(row)
        for row in rows:
            tree.insert("", tk.END, values=row)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudieron leer las encuestas: {e}")
    finally:
        conn.close()

# Actualizar un registro existente
def actualizar_encuesta():
    try:
        conn = conectar()
        cursor = conn.cursor()
        selected = tree.focus()
        if not selected:
            messagebox.showerror("Error", "Selecciona un registro para actualizar.")
            return
        values = tree.item(selected, 'values')
        id_encuesta = values[0]
        query = f"UPDATE ENCUESTA SET BebidasSemana = %s, CervezasSemana = %s WHERE idEncuesta = %s"
        data = (bebidas_semana_entry.get(), cervezas_semana_entry.get(), id_encuesta)
        cursor.execute(query, data)
        conn.commit()
        messagebox.showinfo("Éxito", "Encuesta actualizada correctamente.")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo actualizar la encuesta: {e}")
    finally:
        conn.close()
        leer_encuestas()

# Eliminar un registro
def eliminar_encuesta():
    try:
        conn = conectar()
        cursor = conn.cursor()
        selected = tree.focus()
        if not selected:
            messagebox.showerror("Error", "Selecciona un registro para eliminar.")
            return
        values = tree.item(selected, 'values')
        id_encuesta = values[0]
        if messagebox.askyesno("Confirmación", "¿Estás seguro de que deseas eliminar este registro?"):
            query = "DELETE FROM ENCUESTA WHERE idEncuesta = %s"
            cursor.execute(query, (id_encuesta,))
            conn.commit()
            messagebox.showinfo("Éxito", "Encuesta eliminada correctamente.")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo eliminar la encuesta: {e}")
    finally:
        conn.close()
        leer_encuestas()
